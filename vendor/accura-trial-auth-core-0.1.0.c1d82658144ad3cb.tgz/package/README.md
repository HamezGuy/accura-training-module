# @accura-trial/auth-core

Shared authentication primitives for the **AccuraTrial EDC identity authority**.
Passwords and EDC refresh sessions are owned by `libreclinicaapi`. Command Center
delegates credential verification to EDC and issues short-lived, audience-specific
RS256 assertions to Intelligence Layer and OpenStudyBuilder. Child applications
must not receive `JWT_SECRET` or mint EDC identities.

## What lives here

| Module | Contents |
|---|---|
| `types.ts` | Canonical JWT claim shape (`JwtPayload`), issuer/audience constants, password policy types, logger port |
| `jwt.core.ts` | `createJwtService()` — HS256 token mint/verify, token pairs with stable `sid`, refresh flow |
| `password.core.ts` | MD5+bcrypt dual hashing, `verifyAndUpgrade` (transparent MD5→bcrypt migration), policy validation, lockout helpers |
| `roles.core.ts` | The 6-role EDC model (admin, data_manager, investigator, coordinator, monitor, viewer) + legacy LibreClinica alias resolution |
| `auth-client.ts` | `AccuraAuthClient` — HTTP client satellite services use to delegate login/refresh/verify to the AccuraTrial API |

## Current architecture

```
 credentials → Command Center → EDC API/user_account (authority)
                    │
                    ├─ RS256 aud=accuratrial-intelligence-layer → IL
                    └─ RS256 aud=accuratrial-openstudybuilder   → OSB

 EDC user action → EDC bearer → Command Center /__gateway/<app>/api
                                      └─ validates with EDC, substitutes RS256
```

- **AccuraTrial side:** `libreclinicaapi/src/utils/jwt.util.ts`,
  `utils/password.util.ts`, and `constants/roles.ts` are thin bindings that
  re-export from this package (same export surface as before extraction — no
  call sites changed).
- **Child side:** Command Center exposes public JWKS. IL and OSB verify RS256
  issuer/audience/expiry and use stable subject `edc:<user_id>`. Interactive
  credential endpoints do not exist in child APIs.
- **Server-to-server user actions:** EDC forwards the initiating user's access
  token to Command Center's authority bridge. The gateway verifies it with EDC
  and replaces it with the correct child-audience token; no HS256 secret is
  shared and audit identity is preserved.

## Configuration

`JWT_SECRET` is configured only on the EDC authority. Command Center does not
need it. Child applications configure `COMMAND_CENTER_ISSUER`, public
`COMMAND_CENTER_JWKS_URI`, and their own audience.

`AccuraAuthClient.verify()` calls the authority's protected `/api/auth/verify`
endpoint and returns its identity under `data`: `userId`, `username`, `email`,
`role`, `userType`, `studyIds`, and `organizationIds`. The optional legacy `user`
member remains supported. Callers must validate the returned identity and scope
before authorizing an action; the client does not replace those checks.

Every parsed verification result includes `httpStatus` from the HTTP response,
overriding any JSON field of that name. A 401/403 refusal is therefore distinct
from a 5xx authority failure. Failure results discard identities and credentials,
retaining only the failure message and optional native `error.code` and
`error.message` strings, including `PASSWORD_EXPIRED`. Error codes longer than
128 characters are discarded; nested messages are limited to 1024 characters.
Malformed JSON is a failure with its actual HTTP status. Verification rejects
redirects, and network, timeout, redirect, or response-body transport failures
throw instead of returning an authentication decision. Login and refresh result
behavior is unchanged.

## Build

```bash
cd "C:\Projects\EDCProject\accura-auth"
npm ci
npm run build
npm test
```

Production consumers use a full HTTPS Git commit SHA in `package.json` and
`package-lock.json`. Update that pin only after this package's build and
typecheck pass; never deploy a branch name or a mutable tag.

`npm test` builds the public package and runs offline regression checks for JWT
signature/issuer/audience/expiry boundaries, session rotation, legacy password
migration, role aliases, and delegated authentication failures. Tests use fictional
identities and mocked HTTP responses; they do not create native EDC accounts or
qualify the deployed authority. CI runs these checks before packing the package.

Verified access and refresh tokens require a positive safe integer account ID,
a nonblank username, and integer `iat`/`exp` claims with `exp > iat`. Access tokens
also require a nonblank role and an email string (legacy empty email is allowed).
An optional `sid` must be a nonblank string; legacy tokens without `sid` remain
supported. Refresh may update an account's name or roles, but its lookup must
return the same account ID. These package checks supplement the authority's
session, revocation and current-account checks; they do not replace them.
